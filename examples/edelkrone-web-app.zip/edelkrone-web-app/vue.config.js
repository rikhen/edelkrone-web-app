module.exports = {
  outputDir: 'www',
  assetsDir: 'assets',
  productionSourceMap: false,
  configureWebpack: {
    performance: {
      hints: false
    }
  }
}
