<template lang="pug">
.icon
  img(src="../../assets/icon-loading.gif")
</template>
