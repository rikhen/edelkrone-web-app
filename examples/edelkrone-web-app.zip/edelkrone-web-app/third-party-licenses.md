# Third Party Licenses

### axios
License: MIT  
https://github.com/axios/axios/blob/master/LICENSE

### core-js
License: MIT  
https://github.com/zloirock/core-js/blob/master/LICENSE

### lodash
License: MIT  
https://github.com/lodash/lodash/blob/master/LICENSE

### nipplejs
License: MIT  
https://github.com/yoannmoinet/nipplejs/blob/master/LICENSE

### vue
License: MIT  
https://github.com/vuejs/vue/blob/dev/LICENSE

### vue-router
License: MIT  
https://github.com/vuejs/vue-router/blob/dev/LICENSE

### vue-wait
License: MIT  
https://github.com/f/vue-wait/blob/master/LICENSE

### vuex
License: MIT  
https://github.com/vuejs/vuex/blob/dev/LICENSE

### vuex-persistedstate
License: MIT  
https://github.com/robinvdvleuten/vuex-persistedstate/blob/master/LICENSE

### normalize.css
License: MIT  
https://github.com/necolas/normalize.css/blob/master/LICENSE.md

### flexiblegs-scss
License: MIT  
https://github.com/flexiblegs/flexiblegs-scss/blob/master/LICENSE

### roboto
License: Apache License 2.0  
https://github.com/googlefonts/roboto/blob/main/LICENSE
